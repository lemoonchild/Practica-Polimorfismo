import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * Ejercicio en clase - trabajadores
 * 
 * Clase vista - permite la interacción con el usuario con métodos para mostrar y recibir información a través de la consola.
 */

public class vista {
    Scanner scan = new Scanner(System.in);

    /**
     * Imprime una solicitud y recibe un dato tipo int
     * Evita una excepción -InputMismatchException- volviendo a solicitar el dato en
     * caso de que ocurra.
     *
     * @param solicitud texto que describe lo solicitado
     * @return entero ingresado por el usuario
     */
    public int solicitarI(String solicitud) {
        System.out.println(solicitud);
        int solicitar = 0;
        Boolean correcto = false;
        do {
            try {
                solicitar = scan.nextInt();
                correcto = true;
            } catch (InputMismatchException e) {
                scan.next();
                System.out.println("¡Cuidado! Ingresa un número entero.");
            }
        } while (correcto == false);
        scan.nextLine(); // Elimina la posibilidad de saltarse una linea de solicitud después
        return solicitar;
    }

    public Double solicitarD(String solicitud) {
        System.out.println(solicitud);
        Double solicitar = 0.0;
        Boolean correcto = false;
        do {
            try {
                solicitar = scan.nextDouble();
                correcto = true;
            } catch (InputMismatchException e) {
                scan.next();
                System.out.println("¡Cuidado! Ingresa un número entero.");
            }
        } while (correcto == false);
        scan.nextLine(); // Elimina la posibilidad de saltarse una linea de solicitud después
        return solicitar;
    }

    /**
     * Imprime un texto solicitado
     * 
     * @param text texto a imprimir
     */
    public void Mostrar(String text) {
        System.out.println("\n" + text);
    }

    /**
     * Imprime elementos de tipo trabajador
     * 
     * @param t trabajador a imprimir
     */
    public void MostrarTrabajador(trabajadores t) {
        System.out.println("\n" + t);
    }

    /**
     * Imprime una solicitud y recibe un dato tipo String.
     * 
     * @param solicitud texto que describe la solicitud al usuario
     * @return regresa el texto dado por el usuario
     */
    public String solicitarS(String solicitud) {
        System.out.println(solicitud);
        String solic = scan.nextLine();
        return solic;
    }

    public boolean solicitarB(String solicitud) {
        System.out.println(solicitud);
        boolean solic = scan.nextBoolean();
        return solic;
    }

    public boolean menu_es_docente() {
        System.out.println("\nQue tipo de trabajador es?");
        System.out.println("\t1.) Docente");
        System.out.println("\t2.) No Docente");
        int docenteria = solicitarI("");
        boolean solic = true;
        if (docenteria == 1) {
            solic = true;
        }
        if (docenteria == 2) {
            solic = false;
        }
        return solic;
    }

    public int menu_de_grado_científico() {
        System.out.println("¿Cuál es su grado científico?");
        System.out.println("1. Master");
        System.out.println("2. Doctorado");
        System.out.println("3. Ninguno");

        int grado = solicitarI("");
        return grado;
    }

    public int menu_de_puesto() {
        System.out.println("¿Qué tipo de puesto tiene?");
        System.out.println("1.) Decano");
        System.out.println("2.) Maestro");
        System.out.println("3.) Auxiliar");
        System.out.println("4.) Secretaria");
        System.out.println("5.) Ninguno de los anteriores");
        int sol = solicitarI("");
        return sol;
    }
}
