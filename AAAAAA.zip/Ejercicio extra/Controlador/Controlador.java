import java.util.ArrayList;

import javax.xml.transform.Source;

public class Controlador {
    boolean Es_Docente; // False es no_docente, True es docente
    trabajadores trabajador;
    Docente docente;
    No_Docente no_docente;
    ArrayList<trabajadores> Trabajador_ingresados = new ArrayList<>();
    vista vista = new vista();

    public void Verificar_tipo_de_Trabajador() {
        Es_Docente = vista.menu_es_docente();
    }

    public void Crear_trabajador() {
        int per = vista.solicitarI("Cuántos trabajadores quieres agregar?"); // Pide cuantos personas quiere
        for (int i = 0; i < per; i++) { // De esos hace una vez cada función por números que hay
            Verificar_tipo_de_Trabajador(); // Verifica que tipo de personas es
            if (Es_Docente == false) {
                No_Docente nodocente_temp = new No_Docente(vista.solicitarS("Cuál es el nombre de tu persona"),
                        vista.solicitarS("Cuáles la identificación de tu persona"),
                        vista.solicitarI("Cuál es su salario base"),
                        vista.solicitarI("Cuántas ausencias ha tenido"),
                        vista.solicitarI("Cuántos feriados tuvo?"));
                Trabajador_ingresados.add(nodocente_temp);
            }
            if (Es_Docente == true) {
                Docente docente_temp = new Docente(vista.solicitarS("Cuál es el nombre de tu persona"),
                        vista.solicitarS("Cuáles la identificación de tu persona"),
                        vista.solicitarI("Cuál es su salario base"),
                        vista.solicitarI("¿Cuántas horas de ausencia tiene?"),
                        vista.solicitarD("¿Cuántos años de anitugedad tiene?"),
                        vista.menu_de_grado_científico(),
                        vista.menu_de_puesto());
                Trabajador_ingresados.add(docente_temp);
            }
        }

        for (trabajadores empleado : Trabajador_ingresados) {
            vista.MostrarTrabajador(empleado);
        }
    }

    public void Imprimir_Trabajadores_en_lista() {
        int puesto = 1;
        for (trabajadores trabajador : Trabajador_ingresados) {
            vista.Mostrar("Trabajador número  " + puesto);
            vista.MostrarTrabajador(trabajador);
            puesto++;
        }

    }
}
